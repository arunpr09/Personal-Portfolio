<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];

  // Modify the following lines to customize the email recipient and subject
  $to = 'arunpraveenraj255@gmail.com';
  $subject = 'New Contact Form Submission: ' . $subject;
  $message = "Name: $name\nEmail: $email\n\n$message";

  // Send the email
  if (mail($to, $subject, $message)) {
    echo 'Thank you! Your message has been sent.';
  } else {
    echo 'Sorry, there was an error sending your message. Please try again later.';
  }
}
?>
